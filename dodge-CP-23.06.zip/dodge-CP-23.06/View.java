
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import javax.swing.Timer;

public class View extends JComponent implements ModelBeobachter
{
    private Raumschiff raumschiff;
    private JFrame fenster;

    public View(Raumschiff r){
        raumschiff = r;
        r.anmelden(this);        
        setFocusable(true);
       // fenster = new JFrame();
       // fenster.add(this);
       // fenster.setSize(1950, 1100);
        //fenster.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //fenster.setVisible(true);
    }
    
    private static void createAndShowUI(){
        AsteroidPanel panel = new AsteroidPanel();

        fenster = new JFrame();
        fenster.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fenster.add(panel);
        fenster.setSize(1950, 1100);
        fenster.setLocationRelativeTo( null );
        fenster.setVisible(true);
        
        panel.addAsteroids(20);
        panel.runGameWithTimer();
    }
    
    public void raumschiffGeaendert(){
        repaint();
    }
    
    public void asteroidGeaendert(){
        repaint();
    }

    public void entergedrückt()
    {
        repaint();
        // bin mir nicht sicher
    }
    
    public void paint(Graphics g){
        g.setColor(Color.BLACK);
        Dimension size = getSize();
        g.fillRect(0, 0, size.width, size.height);
        g.drawPolygon(new int[] {980,1000,990}, new int[] {1000,1000,900}, 3);
        g.setColor(Color.WHITE);
        g.fillPolygon(new int[] {980,1000,990}, new int[] {1000,1000,900}, 3);
       // g.fillRect(raumschiff.getX(), raumschiff.getY(), 
            //raumschiff.getSeitenlaengeX(),raumschiff.getSeitenlaengeY());
    }
}
