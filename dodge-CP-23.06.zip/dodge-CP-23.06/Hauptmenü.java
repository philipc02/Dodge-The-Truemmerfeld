import java.util.ArrayList;

public class Hauptmenü
{
    private ArrayList<ModelBeobachter> beobachter;
    
    public void fensterschließen()
    {
        // Hauptmenü löschen und das Spiel starten 
        alleInformieren();
    }
    
    public void anmelden(ModelBeobachter b){
        beobachter.add(b);
    }
    
    public void abmelden(ModelBeobachter b){
        beobachter.remove(b);
    }
    
    private void alleInformieren(){
        for (ModelBeobachter b : beobachter){
            b.entergedrückt();
        }
    }
}
