public class randomNumbers
{
    private int randPos, randNeg;

    public void rngPos(){
        int min = 0;
        int max = 1820; 
        int a = (int)Math.floor(Math.random()*(max-min+1)+min);
        randPos = a;
    }

    public void rngNeg(){
        int min = -2500;
        int max = -100; 
        int b = (int)Math.floor(Math.random()*(max-min+1)+min);
        randNeg = b;
    }

    public int getRandPos(){
        rngPos();
        return randPos;   
    }

    public int getRandNeg(){
        rngNeg();
        return randNeg;   
    }
}
