/**
 * Class randomNumbers - Eine Klasse, die zufällige Zahlen in einem bestimmten Bereich generiert.
 * 
 * @author Stefan Steyer
 * 
 * @version 2021.07.14
 */
public class randomNumbers
{
    private int randPos, randNeg;
/**
 * Erzeugt eine zufällige Zahl zwischen 0 und 1820 und speichert diese in einer Variable.
 */
    public void rngPos(){
        int min = 0;
        int max = 1820; 
        int a = (int)Math.floor(Math.random()*(max-min+1)+min);
        randPos = a;
    }

/**
 * Erzeugt eine zufällige Zahl zwischen -2500 und -100 und speichert diese in einer Variable.
 */
    public void rngNeg(){
        int min = -2500;
        int max = -100; 
        int b = (int)Math.floor(Math.random()*(max-min+1)+min);
        randNeg = b;
    }

/**
 * Führt rngPos() aus und gibt die generierte Variable zurück.
 */
    public int getRandPos(){
        rngPos();
        return randPos;   
    }

/**
 * Führt rngNeg() aus und gibt die generierte Variable zurück.
 */
    public int getRandNeg(){
        rngNeg();
        return randNeg;   
    }
}
