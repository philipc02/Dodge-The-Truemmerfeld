import java.util.ArrayList;

public class Raumschiff 
{
    private int x, y;
    private ArrayList<ModelBeobachter> beobachter; 
    
    public Raumschiff(){
        x = 980;
        y = 300;
        
        beobachter = new ArrayList<ModelBeobachter>();
    }
    
    public int getX(){
        return x;
    }
    
    public int getY(){
        return y;
    }
  
    //public int getSeitenlaengeX(){
       // return seitenlaengeX;
    //}
    
    //public int getSeitenlaengeY(){
      //  return seitenlaengeY;
    //}
    
    public void anmelden(ModelBeobachter b){
        beobachter.add(b);
    }
    
    public void abmelden(ModelBeobachter b){
        beobachter.remove(b);
    }
    
    private void alleInformieren(){
        for (ModelBeobachter b : beobachter){
            b.raumschiffGeaendert();
        }
    }
    
    void nachRechtsBewegen(){
        if(x<1200){
            x = x + 5;
        }
        alleInformieren();
    }
    
    void nachLinksBewegen(){
        if(x>800){
            x = x - 5;
        }
        alleInformieren();
    }
    
    void nachObenBewegen(){
        y = y - 10;
        alleInformieren();
    }
}
