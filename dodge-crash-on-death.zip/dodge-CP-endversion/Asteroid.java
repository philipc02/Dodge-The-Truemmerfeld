import java.util.ArrayList;

public class Asteroid 
{
    private int x,y, width, height;
    private ArrayList<ModelBeobachter> beobachter;
    private randomNumbers rand;

    public Asteroid(int width){
        rand = new randomNumbers();
        x=rand.getRandPos();
        y=rand.getRandNeg();
        this.width = width;
        this.height = View.abild.getHeight()/View.abild.getWidth()*width;
        
        beobachter = new ArrayList<ModelBeobachter>();
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }
    
    public int getWidth(){
        return width;
    }
    
    public int getHeight(){
        return height;
    }

    private void alleInformieren(){
        for (ModelBeobachter b : beobachter){
            b.asteroidGeaendert();
        }
    }

    public void anmelden(ModelBeobachter b){
        beobachter.add(b);
    }

    public void abmelden(ModelBeobachter b){
        beobachter.remove(b);
    }

    public void fallen(){
        y = y + 1;
        
        if(y > 1100){
            x = rand.getRandPos();
            y = rand.getRandNeg();
        }
    }
}