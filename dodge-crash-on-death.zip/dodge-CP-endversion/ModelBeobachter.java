public interface ModelBeobachter
{
    public void raumschiffGeaendert();
    public void asteroidGeaendert();
    public void hauptmenueGeaendert();
}
