
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import java.lang.Thread;

public class View extends JComponent implements ModelBeobachter
{
    private Raumschiff raumschiff;
    private Asteroid asteroid1, asteroid2, asteroid3,asteroid4, asteroid5;
    private Hauptmenü hauptmenü;
    private JFrame fenster;
    public static BufferedImage rbild, abild, hintergrund, hbild;
    private Controller controller;

    public View(Controller controller, Hauptmenü h, Raumschiff r, Asteroid a1,Asteroid a2, Asteroid a3, Asteroid a4, Asteroid a5){
        this.controller = controller;
        hauptmenü = h;
        raumschiff = r;
        asteroid1 = a1;
        asteroid2 = a2;
        asteroid3 = a3;
        asteroid4 = a4;
        asteroid5 = a5;
        h.anmelden(this);
        r.anmelden(this);
        a1.anmelden(this);
        a2.anmelden(this);
        a3.anmelden(this);
        a4.anmelden(this);
        a5.anmelden(this);
        setFocusable(true);
        fenster = new JFrame("Dodge The Trümmerfeld");
        fenster.add(this);
        fenster.setSize(1950, 1100);
        fenster.setBackground(Color.BLACK);
        fenster.setExtendedState(JFrame.MAXIMIZED_BOTH); //startet in Vollbild
        fenster.setUndecorated(false);      //entfernt den Ramen wenn auf true
        fenster.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fenster.setVisible(true);
        repaint();
    }

    public void raumschiffGeaendert(){
        repaint();
    }

    public void asteroidGeaendert(){
        repaint();
    }

    public void hauptmenueGeaendert()
    {
        repaint();
    }

    public void paint(Graphics g){
        super.paintComponent(g);
        Graphics2D g2d= (Graphics2D)g;
        g2d.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON) ;

        g.drawImage(hintergrund,0,0,100000,100000,null);

        g.drawImage(rbild,raumschiff.getX(),raumschiff.getY(),100,100,null);

        g.drawImage(abild,asteroid1.getX(),asteroid1.getY(),asteroid1.getWidth(),asteroid1.getHeight(),null);
        g.drawImage(abild,asteroid2.getX(),asteroid2.getY(),asteroid2.getWidth(),asteroid2.getHeight(),null);
        g.drawImage(abild,asteroid3.getX(),asteroid3.getY(),asteroid3.getWidth(),asteroid3.getHeight(),null);
        g.drawImage(abild,asteroid4.getX(),asteroid4.getY(),asteroid4.getWidth(),asteroid4.getHeight(),null);
        g.drawImage(abild,asteroid5.getX(),asteroid5.getY(),asteroid5.getWidth(),asteroid5.getHeight(),null);

        if(controller.timeRunning()){
            controller.nextFrame();
        }

        else{
            g.drawImage(hbild,hauptmenü.getX(),hauptmenü.getY(),1000,1000,null);
        }
    }
}
