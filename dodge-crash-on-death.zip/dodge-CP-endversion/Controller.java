
import java.awt.event.*;
import java.lang.Thread;
import java.awt.Rectangle;

public class Controller implements KeyListener
{
    private Raumschiff raumschiff;
    private Asteroid asteroid1, asteroid2, asteroid3, asteroid4, asteroid5;
    private View view;
    private Hauptmenü hauptmenü;
    private boolean hIstOben;
    private int hp = 3;
    private long startzeit;

    public Controller(){
        raumschiff = new Raumschiff();
        asteroid1 = new Asteroid(100);
        asteroid2 = new Asteroid(125);
        asteroid3 = new Asteroid(125);
        asteroid4 = new Asteroid(150);
        asteroid5 = new Asteroid(200);
        hauptmenü = new Hauptmenü();
        view = new View(this, hauptmenü, raumschiff, asteroid1, asteroid2, asteroid3, asteroid4, asteroid5);
        view.addKeyListener(this);
        hIstOben = true;
    }

    public void keyReleased(KeyEvent e){}

    public void keyPressed(KeyEvent e){
        if(e.getKeyCode() == KeyEvent.VK_RIGHT){
            if(hIstOben == false){
                raumschiff.nachRechtsBewegen();
            }
        }
        if(e.getKeyCode() == KeyEvent.VK_LEFT){
            if(hIstOben == false){
                raumschiff.nachLinksBewegen();
            }
        }
        if(e.getKeyCode() == KeyEvent.VK_UP){
            if(hIstOben == false){
                raumschiff.nachObenBewegen();
            }
        }
        if(e.getKeyCode() == KeyEvent.VK_DOWN){
            if(hIstOben == false){
                raumschiff.nachUntenBewegen();
            }
        }

        if(e.getKeyCode() == KeyEvent.VK_ENTER){
            if(hIstOben){
                hauptmenü.hauptmenueUnten();
                hIstOben = false;
                startzeit = System.currentTimeMillis();
                nextFrame();
            } 
        }
    }

    public void keyTyped(KeyEvent e) {}

    public void nextFrame(){
        fallenLassen();
        if(checkCollision(asteroid1) || checkCollision(asteroid2) || checkCollision(asteroid3) || checkCollision(asteroid4) || checkCollision(asteroid5)){
            System.exit(0);
        }
        try{
            Thread.sleep(5);
        }
        catch(InterruptedException e){
            e.printStackTrace();
        }
        view.repaint();
    }

    public void fallenLassen(){
        asteroid1.fallen();
        asteroid2.fallen();
        asteroid3.fallen();
        asteroid4.fallen();
        asteroid5.fallen();
    }

    public boolean checkCollision(Asteroid a){
        Rectangle hbr = new Rectangle(raumschiff.getX(),raumschiff.getY(),100,100);
        Rectangle hba = new Rectangle(a.getX(),a.getY(),a.getWidth(),a.getHeight());
        return hbr.intersects(hba);
    }

    public boolean timeRunning()
    {
        if(System.currentTimeMillis() - startzeit > 60000 || startzeit == 0f){
            return false;
        }
        return true;
    }
}
