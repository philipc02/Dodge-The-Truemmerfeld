import java.util.ArrayList;

public class Hauptmenü
{
    private int x, y;
    private ArrayList<ModelBeobachter> beobachter;

    public Hauptmenü(){
        x=0;
        y=0;

        beobachter = new ArrayList<ModelBeobachter>();
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }

    private void alleInformieren(){
        for (ModelBeobachter b : beobachter){
            b.hauptmenueGeaendert();
        }
    }

    public void anmelden(ModelBeobachter b){
        beobachter.add(b);
    }

    public void abmelden(ModelBeobachter b){
        beobachter.remove(b);
    }

    void hauptmenueUnten(){
        y = y + 1100;

        alleInformieren();
    }
}
