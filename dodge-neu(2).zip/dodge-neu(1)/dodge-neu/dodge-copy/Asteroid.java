
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import javax.swing.Timer;

public class Asteroid{
        private static void createAndShowUI()
        {
        AsteroidPanel panel = new AsteroidPanel();

        JFrame frame = fenster;
        panel.addAsteroids(20);
        panel.startAnimation();
       }

       public static void main(String[] args)
       {
        EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                createAndShowUI();
            }
        });
       }
    }
