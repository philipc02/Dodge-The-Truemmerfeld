import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

 

public class Main {
    public static void main(String[] args){
        new Controller();
        try {
            View.rbild = ImageIO.read(new File("H:/Dodge the Trümmerfeld Zeug/DodgeTheTrümmerfeld/rsc/raumschiff.png"));
            View.abild = ImageIO.read(new File("H:/Dodge the Trümmerfeld Zeug/DodgeTheTrümmerfeld/rsc/asteroid.png"));
            View.hintergrund = ImageIO.read(new File("H:/Dodge the Trümmerfeld Zeug/DodgeTheTrümmerfeld/rsc/black.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Bilder laden nicht");

 

        }
        
     


    }

 

}