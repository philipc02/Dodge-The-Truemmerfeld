

public class Asteroid 
    {
        private int x,y;
        public Asteroid(){
            randomNumbers rand=new randomNumbers();
            x=rand.getRand();
        }
        
    }