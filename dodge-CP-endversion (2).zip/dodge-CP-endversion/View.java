
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import javax.swing.Timer;

public class View extends JComponent implements ModelBeobachter
{
    private Raumschiff raumschiff;
    private Asteroiden asteroiden;
    private JFrame fenster;
    public static BufferedImage rbild, abild, hintergrund;
    public int aX1, aY1, aX2, aY2, aX3, aY3, aX4, aY4, aX5, aY5;
   
    
    public View(Raumschiff r){
        raumschiff = r;
        r.anmelden(this);        
        setFocusable(true);
       fenster = new JFrame("Dodge The Trümmerfeld");
        fenster.add(this);
        fenster.setSize(1950, 1100);
        fenster.setBackground(Color.BLACK);
        fenster.setExtendedState(JFrame.MAXIMIZED_BOTH); //startet in Vollbild
        fenster.setUndecorated(false);      //entfernt den Ramen wenn auf true
        fenster.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fenster.setVisible(true);
        aY1=0;
        
    }
    
    
     public void setKoordinaten(){
        randomNumbers rand=new randomNumbers();
        aX1=rand.getRand();
        aX2=rand.getRand();
        aX3=rand.getRand();
        aX4=rand.getRand();
        aX5=rand.getRand();
    }
    
    public void raumschiffGeaendert(){
        repaint();
    }
    
    public void asteroidGeaendert(){
        repaint();
    }

    public void entergedrückt()
    {
        repaint();
        // bin mir nicht sicher
    }
    
    public void paint(Graphics g){
       super.paintComponent(g);
        Graphics2D g2d= (Graphics2D)g;
        g2d.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON) ;
        
        g.drawImage(hintergrund,0,0,1000000,1000000,null);

        g.drawImage(rbild,raumschiff.getX(),raumschiff.getY(),100,100,null);
        
        g.drawImage(abild,aX1,aY2,200,200,null);
        g.drawImage(abild,aX2,aY2,100,100,null);
        g.drawImage(abild,aX3,aY3,100,100,null);
        g.drawImage(abild,aX4,aY4,100,100,null);
        g.drawImage(abild,aX5,aY5,100,100,null);

        repaint();

    }
}
