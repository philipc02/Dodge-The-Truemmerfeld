import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import javax.swing.Timer;


public class Asteroiden extends JPanel implements ActionListener
{

    private ArrayList<ModelBeobachter> asteroid_list; 
    

    public Asteroiden(){
        setLayout( null );
        // setBackground( Color.BLACK );
        asteroid_list = new ArrayList<ModelBeobachter>();
    }

    

 

    public void addAsteroids(int asteroidCount)
    {
        Random random = new Random();

        for (int i = 0; i < 21; i++)
        {
            Asteroid asteroid = new Asteroid();
            //asteroid.setRandomColor(true);
            //asteroid.setLocation(random.nextInt(getWidth()), random.nextInt(getHeight()));
            asteroid.setMoveRate(32, 32, 1, 1, true);
            //          asteroid.setMoveRate(16, 16, 1, 1, true);
            //asteroid.setSize(32, 32);
            asteroid_list.add( asteroid );
        }
    }

    @Override
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);

        for (Asteroid asteroid: asteroid_list)
        {
            asteroid.draw(g);
        }
    }

    //public void startAnimation()
    //{
    //  Timer timer = new Timer(75, this);
    //  timer.start();
    //}

    public void actionPerformed(ActionEvent e)
    {
        move();
        repaint();
    }

    private void move()
    {
        for (ModelBeobachter b : asteroid_list)
        {
            b.move(this);
        }
    }

    public void anmelden(ModelBeobachter b){
        asteroid_list.add(b);
    }

    public void abmelden(ModelBeobachter b){
        asteroid_list.remove(b);
    }

    private void alleInformieren(){
        for (ModelBeobachter b : asteroid_list){
            b.asteroidGeaendert();
        }
    }
}
