import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

 

public class Main {
    public static void main(String[] args){
        
        try {
            View.rbild = ImageIO.read(new File("//ads/schueler$/home/steyers23/Dodge the Trümmerfeld Zeug/dodge-CP-endversion/rsc/raumschiff.png"));
            View.abild = ImageIO.read(new File("//ads/schueler$/home/steyers23/Dodge the Trümmerfeld Zeug/dodge-CP-endversion/rsc/asteroid.png"));
            View.hintergrund = ImageIO.read(new File("//ads/schueler$/home/steyers23/Dodge the Trümmerfeld Zeug/dodge-CP-endversion/rsc/black.png"));
            View.hbild = ImageIO.read(new File("//ads/schueler$/home/steyers23/Dodge the Trümmerfeld Zeug/dodge-CP-endversion/rsc/menu.png"));
            View.gbild = ImageIO.read(new File("//ads/schueler$/home/steyers23/Dodge the Trümmerfeld Zeug/dodge-CP-endversion/rsc/GameOver.png"));
            View.vbild = ImageIO.read(new File("//ads/schueler$/home/steyers23/Dodge the Trümmerfeld Zeug/dodge-CP-endversion/rsc/Victory.png"));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Bilder laden nicht");

 

        }
        Controller control = new Controller();
     


    }

 

}