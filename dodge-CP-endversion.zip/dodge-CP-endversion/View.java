
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import javax.swing.Timer;
import java.util.concurrent.TimeUnit;

public class View extends JComponent implements ModelBeobachter
{
    private Raumschiff raumschiff;
    private Asteroid asteroid1, asteroid2, asteroid3,asteroid4, asteroid5;
    private JFrame fenster;
    public static BufferedImage rbild, abild, hintergrund;
    private boolean timeisrunning;

    
    public View(Raumschiff r, Asteroid a1,Asteroid a2, Asteroid a3, Asteroid a4, Asteroid a5){
        raumschiff = r;
        asteroid1 = a1;
        asteroid2 = a2;
        asteroid3 = a3;
        asteroid4 = a4;
        asteroid5 = a5;
        r.anmelden(this);        
        setFocusable(true);
        fenster = new JFrame("Dodge The Trümmerfeld");
        fenster.add(this);
        fenster.setSize(1950, 1100);
        fenster.setBackground(Color.BLACK);
        fenster.setExtendedState(JFrame.MAXIMIZED_BOTH); //startet in Vollbild
        fenster.setUndecorated(false);      //entfernt den Ramen wenn auf true
        fenster.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fenster.setVisible(true);
        timeRunning();

    }

    public void timeRunning()
    {
        long time = System.currentTimeMillis();
        long endTime = time + 60000;
        timeisrunning=false;
        while(time < endTime){
            timeisrunning=true;
            asteroid1.fallen();
            for(int x = 0; x < 1000; x++){
                
            }
        }
        timeisrunning = false;

    }

    public void raumschiffGeaendert(){
        repaint();
    }

    public void asteroidGeaendert(){
        repaint();
    }

    public void entergedrückt()
    {
        repaint();
        // bin mir nicht sicher
    }

    public void paint(Graphics g){
        super.paintComponent(g);
        Graphics2D g2d= (Graphics2D)g;
        g2d.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON) ;

        g.drawImage(hintergrund,0,0,1000000,1000000,null);

        // while (timeisrunning){
        g.drawImage(rbild,raumschiff.getX(),raumschiff.getY(),100,100,null);

        g.drawImage(abild,asteroid1.getX(),asteroid1.getY(),200,200,null);
        g.drawImage(abild,asteroid2.getX(),asteroid2.getY(),100,100,null);
        g.drawImage(abild,asteroid3.getX(),asteroid3.getY(),100,100,null);
        g.drawImage(abild,asteroid4.getX(),asteroid4.getY(),100,100,null);
        g.drawImage(abild,asteroid5.getX(),asteroid5.getY(),100,100,null);

        //repaint();
        //  }
    }
}
