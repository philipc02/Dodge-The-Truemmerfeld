
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import java.lang.Thread;

public class View extends JComponent implements ModelBeobachter
{
    private Raumschiff raumschiff;
    private Asteroid[] asteroiden;
    private Hauptmenü hauptmenü;
    private JFrame fenster;
    public static BufferedImage rbild, abild, hintergrund, hbild, gbild, vbild;
    private Controller controller;

    public View(Controller controller, Hauptmenü h, Raumschiff r, Asteroid[] a){
        this.controller = controller;
        hauptmenü = h;
        raumschiff = r;
        asteroiden = a;
        h.anmelden(this);
        r.anmelden(this);
        for(Asteroid as : asteroiden){
            as.anmelden(this);
        }
        setFocusable(true);
        fenster = new JFrame("Dodge The Trümmerfeld");
        fenster.add(this);
        fenster.setSize(1950, 1100);
        fenster.setBackground(Color.BLACK);
        fenster.setExtendedState(JFrame.MAXIMIZED_BOTH); //startet in Vollbild
        fenster.setUndecorated(false);      //entfernt den Ramen wenn auf true
        fenster.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fenster.setVisible(true);
        repaint();
    }

    public void raumschiffGeaendert(){
        repaint();
    }

    public void asteroidGeaendert(){
        repaint();
    }

    public void hauptmenueGeaendert()
    {
        repaint();
    }

    public void paint(Graphics g){
        super.paintComponent(g);
        Graphics2D g2d= (Graphics2D)g;
        g2d.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON) ;

        g.drawImage(hintergrund,0,0,100000,100000,null);

        g.drawImage(rbild,raumschiff.getX(),raumschiff.getY(),100,100,null);

        for(Asteroid a : asteroiden){
            g.drawImage(abild,a.getX(),a.getY(),a.getWidth(),a.getHeight(),null);
        }
        g.setColor(Color.YELLOW);
        switch(controller.getHp()){
            case 3:
            g.fillRect(130, 950, 50, 50);
            case 2:
            g.fillRect(70, 950, 50, 50);            
            case 1:
            g.fillRect(10, 950, 50, 50);            
            break;
        }

        if(controller.getStarted() && !controller.timeRunning()){
            if(controller.getHp() > 0){
                g.drawImage(vbild,0,0,this.getWidth(),this.getHeight(),null);
            }
            else if(controller.getHp() <=0){
                g.drawImage(gbild,0,0,this.getWidth(),this.getHeight(),null);
            }
        }

        if(controller.timeRunning()){
            controller.nextFrame();
        }

        else if(!controller.getStarted()){
            g.drawImage(hbild,hauptmenü.getX(),hauptmenü.getY(),this.getWidth(),this.getHeight(),null);
        }
    }
}
