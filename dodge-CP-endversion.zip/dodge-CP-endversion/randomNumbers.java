
public class randomNumbers
{
    private int rand;
  public randomNumbers(){
      
    }
    
   public void rng(){
     int min = 0;
     int max = 1000; 
     int a = (int)Math.floor(Math.random()*(max-min+1)+min);
     rand = a;
    }
    
    public int getRand(){
     rng();
     return rand;   
    }
}
