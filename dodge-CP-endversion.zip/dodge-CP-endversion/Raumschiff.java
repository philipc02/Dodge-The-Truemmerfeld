import java.util.ArrayList;

public class Raumschiff 
{
    private int x, y;
    private ArrayList<ModelBeobachter> beobachter; 

    public Raumschiff(){
        x=900;
        y=800;

        beobachter = new ArrayList<ModelBeobachter>();
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }

    public void reset(){
        x = 900;
        y = 800;
    }

    public void anmelden(ModelBeobachter b){
        beobachter.add(b);
    }

    public void abmelden(ModelBeobachter b){
        beobachter.remove(b);
    }

    private void alleInformieren(){
        for (ModelBeobachter b : beobachter){
            b.raumschiffGeaendert();
        }
    }

    void nachRechtsBewegen(){
        if(x<1820){
            x = x + 20;   
        }
        alleInformieren();
    }

    void nachLinksBewegen(){
        if(x>0){
            x = x - 20;
        }
        alleInformieren();
    }

    void nachObenBewegen(){
        if(y>0){
            y = y - 20;
        }
        alleInformieren();
    }

    void nachUntenBewegen(){
        if(y<900){
            y = y + 20;
        }
        alleInformieren();
    }
}
