import java.util.ArrayList;

public class Asteroid 
    {
        private int x,y;
        private ArrayList<ModelBeobachter> beobachter;
        
        public Asteroid(){
            randomNumbers rand=new randomNumbers();
            x=rand.getRandPos();
            y=rand.getRandNeg();
            
            beobachter = new ArrayList<ModelBeobachter>();
        }
        
        public int getX(){
        return x;
    }
    
    public int getY(){
        return y;
    }

    private void alleInformieren(){
              for (ModelBeobachter b : beobachter){
                   b.asteroidGeaendert();
              }
    }
        
    
    public void fallen(){
        y = y + 1000;
        alleInformieren();
    }
    }