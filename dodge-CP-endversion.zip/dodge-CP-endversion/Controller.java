
import java.awt.event.*;
import java.lang.Thread;
import java.awt.Rectangle;

public class Controller implements KeyListener
{
    private Raumschiff raumschiff;
    public Asteroid[] asteroiden = new Asteroid[10];
    private View view;
    private Hauptmenü hauptmenü;
    private int hp;
    private long startzeit;
    private boolean gameStarted;

    public Controller(){
        raumschiff = new Raumschiff();
        asteroiden[0] = new Asteroid(200);
        asteroiden[1] = new Asteroid(225);
        asteroiden[2] = new Asteroid(225);
        asteroiden[3] = new Asteroid(250);
        asteroiden[4] = new Asteroid(200);
        asteroiden[5] = new Asteroid(225);
        asteroiden[6] = new Asteroid(225);
        asteroiden[7] = new Asteroid(250);
        asteroiden[8] = new Asteroid(200);
        asteroiden[9] = new Asteroid(200);
        hauptmenü = new Hauptmenü();
        view = new View(this, hauptmenü, raumschiff, asteroiden);
        view.addKeyListener(this);
        gameStarted = false;
    }

    public void keyReleased(KeyEvent e){}

    public void keyPressed(KeyEvent e){
        if(e.getKeyCode() == KeyEvent.VK_RIGHT){
            if(timeRunning()){
                raumschiff.nachRechtsBewegen();
            }
        }
        if(e.getKeyCode() == KeyEvent.VK_LEFT){
            if(timeRunning()){
                raumschiff.nachLinksBewegen();
            }
        }
        if(e.getKeyCode() == KeyEvent.VK_UP){
            if(timeRunning()){
                raumschiff.nachObenBewegen();
            }
        }
        if(e.getKeyCode() == KeyEvent.VK_DOWN){
            if(timeRunning()){
                raumschiff.nachUntenBewegen();
            }
        }

        if(e.getKeyCode() == KeyEvent.VK_ENTER){
            if(!timeRunning()){
                startzeit = System.currentTimeMillis();
                gameStarted = true;
                reset();
                nextFrame();
            } 
        }
        
        if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
            System.exit(0);
        }
    }

    public void keyTyped(KeyEvent e) {}

    public void nextFrame(){
        fallenLassen();

        for(Asteroid a : asteroiden){
            if(checkCollision(a)){
                if(!a.getKollision()){
                    --hp;
                    a.setKollision(true);
                }
            }
            else{
                a.setKollision(false);
            }
        }

        if(hp <= 0){
            startzeit = 0L;
        }

        try{
            Thread.sleep(1);
        }
        catch(InterruptedException e){
            e.printStackTrace();
        }
        view.repaint();
    }

    public void fallenLassen(){
        for(Asteroid a : asteroiden){
            a.fallen();
        }
    }

    public boolean checkCollision(Asteroid a){
        Rectangle hbr = new Rectangle(raumschiff.getX(),raumschiff.getY(),100,100);
        Rectangle hba = new Rectangle(a.getX(),a.getY(),a.getWidth(),a.getHeight());
        return hbr.intersects(hba);
    }

    public boolean timeRunning()
    {
        if(System.currentTimeMillis() - startzeit > 120000 || startzeit == 0f){
            return false;
        }
        return true;
    }

    public void reset(){
        raumschiff.reset();
        for(Asteroid a: asteroiden){
            a.reset();
        }
        hp = 3;
    }

    public int getHp(){
        return hp;
    }

    public boolean getStarted(){
        return gameStarted;
    }
}
