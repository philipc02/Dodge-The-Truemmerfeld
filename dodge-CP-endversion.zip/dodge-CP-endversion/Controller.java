
import java.awt.event.*;

public class Controller implements KeyListener
{
    private Raumschiff raumschiff;
    private Asteroid asteroid1, asteroid2, asteroid3, asteroid4, asteroid5;
    private View view;

    public Controller(){
        raumschiff = new Raumschiff();
        asteroid1 = new Asteroid();
        asteroid2 = new Asteroid();
        asteroid3 = new Asteroid();
        asteroid4 = new Asteroid();
        asteroid5 = new Asteroid();
        view = new View(raumschiff, asteroid1, asteroid2, asteroid3, asteroid4, asteroid5);
        view.addKeyListener(this);
    }

    public void keyReleased(KeyEvent e){}

    public void keyPressed(KeyEvent e){
        if(e.getKeyCode() == KeyEvent.VK_RIGHT){
            raumschiff.nachRechtsBewegen();
        }
        if(e.getKeyCode() == KeyEvent.VK_LEFT){
            raumschiff.nachLinksBewegen();
        }
        if(e.getKeyCode() == KeyEvent.VK_UP){
            raumschiff.nachObenBewegen();
        }
        if(e.getKeyCode() == KeyEvent.VK_DOWN){
            raumschiff.nachUntenBewegen();
        }
        // if(e.getKeyCode() == KeyEvent.VK_ENTER){
        //   Hauptmenü.fensterschließen();
        //} 
    }

    public void keyTyped(KeyEvent e) {}
}
