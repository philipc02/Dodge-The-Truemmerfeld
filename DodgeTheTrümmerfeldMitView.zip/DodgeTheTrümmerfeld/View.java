
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

public class View extends JComponent implements ModelBeobachter
{
    private Raumschiff raumschiff;
    private JFrame fenster;
    public static BufferedImage rbild;

    public View(Raumschiff r){
        raumschiff = r;
        r.anmelden(this);        
        setFocusable(true);
        fenster = new JFrame("Dodge The Trümmerfeld");
        fenster.add(this);
        fenster.setSize(1950, 1100);
        fenster.setBackground(Color.black);
        fenster.setExtendedState(JFrame.MAXIMIZED_BOTH); //startet in Vollbild
        fenster.setUndecorated(false);      //entfernt den Ramen wenn auf true
        fenster.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fenster.setVisible(true);
    }

    public void raumschiffGeaendert(){
        repaint();
    }

    public void asteroidGeaendert(){
        repaint();
    }

    public void paint(Graphics g){


        super.paintComponent(g);
        Graphics2D g2d= (Graphics2D)g;
        g2d.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON) ;


        g.drawImage(rbild,rX,rY,100,100,null);

        repaint();

    }
}
