import java.util.ArrayList;

public class Raumschiff 
{
    private int x, y, seitenlaenge;
    private ArrayList<RaumschiffBeobachter> beobachter; 
    
    public Raumschiff(){
        x = 50;
        y = 50;
        seitenlaenge = 50;
        beobachter = new ArrayList<RaumschiffBeobachter>();
    }
    
    public int getX(){
        return x;
    }
    
    public int getY(){
        return y;
    }
    
    public int getSeitenlaenge(){
        return seitenlaenge;
    }
    
    public void anmelden(RaumschiffBeobachter b){
        beobachter.add(b);
    }
    
    public void abmelden(RaumschiffBeobachter b){
        beobachter.remove(b);
    }
    
    private void alleInformieren(){
        for (RaumschiffBeobachter b : beobachter){
            b.quadratGeaendert();
        }
    }
    
    void nachRechtsBewegen(){
        if(x<100){
            x = x + 5;
        }
        alleInformieren();
    }
    
    void nachLinksBewegen(){
        if(x>5){
            x = x - 5;
        }
        alleInformieren();
    }
    
    void nachObenBewegen(){
        y = y + 10;
        alleInformieren();
    }
}
