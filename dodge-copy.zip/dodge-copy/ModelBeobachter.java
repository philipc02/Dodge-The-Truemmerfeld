public interface ModelBeobachter
{
    public void raumschiffGeaendert();
}
