import javax.swing.*;
import java.awt.*;

public class View extends javax.swing.JComponent implements ModelBeobachter{
    private ModelAsteroiden asteroid;
    private ModelRaumschiff raumschiff;
    private JFrame fenster;
    
    public View(ModelRaumschiff r, ModelAsteroiden a){
        raumschiff = r;
        asteroiden = a;
        r.anmelden(this);
        a.anmelden(this);
        setFocucsable(true);
        fenster = new JFrame();
        fenster.add(this);
        fenster.setSize(1000, 750);
        fenster.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fenster.setVisible(true);
    }
    
    public void modelGeaendert(){
        repaint();
    }
    
    public void paint(Graphics g){
        g.setColor(Color.BLACK);
    }
}