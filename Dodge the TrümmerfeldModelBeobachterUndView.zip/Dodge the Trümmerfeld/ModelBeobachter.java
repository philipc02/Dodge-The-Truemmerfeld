public interface ModelBeobachter{
    
    public abstract void raumschiffGeaendert();
    public abstract void asteroidGeaendert();
}