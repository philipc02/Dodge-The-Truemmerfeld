
public interface ViewBeobachter
{
    
}
