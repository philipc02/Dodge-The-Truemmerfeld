
public class Hauptmenü
{
    public void fensterschließen()
    {
        alleinformieren();
    }
}
