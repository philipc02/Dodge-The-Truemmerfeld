

public interface ModelBeobachter
{
    public abstract void quadratGeaendert();
}
