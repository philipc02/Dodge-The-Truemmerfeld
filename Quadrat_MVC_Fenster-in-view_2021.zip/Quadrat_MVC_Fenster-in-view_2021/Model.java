import java.util.ArrayList;

public class Model 
{
    private int x, y, seitenlaenge;
    private ArrayList<ModelBeobachter> beobachter; 

    public Model(){
        beobachter = new ArrayList<ModelBeobachter>();
        x = 50;
        y = 50;
        seitenlaenge = 50;
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }

    public int getSeitenlaenge(){
        return seitenlaenge;
    }
    
    public void anmelden(ModelBeobachter b){
        beobachter.add(b);
    }
    
    public void abmelden(ModelBeobachter b){
        beobachter.remove(b);
    }
    
    private void alleInformieren(){
        for(ModelBeobachter b : beobachter){
            b.quadratGeaendert();
        }
    }
    
    public void nachRechtsBewegen(){
        x = x+10;
        alleInformieren();
    }
    
    public void nachLinksBewegen(){
        x = x-10;
        alleInformieren();
    }
    
    public void nachObenBewegen(){
        y = y-10;
        alleInformieren();
    }
    
    public void nachUntenBewegen(){
        y = y+10;
        alleInformieren();
    }
}