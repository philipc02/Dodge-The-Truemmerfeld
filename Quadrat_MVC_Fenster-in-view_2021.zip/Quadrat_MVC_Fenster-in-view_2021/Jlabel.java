import javax.swing.*;

public class Jlabel extends JFrame
{
    public Jlabel(){
        JFrame frame =new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800,600);
        frame.setLocation(600,300);
        JLabel label = new JLabel();
        label.setIcon(new ImageIcon("H:/Quadrat_MVC_Fenster-in-view_2021/raumschiff.jpg"));
        label.setLocation(100,100);//--------------
        frame.getContentPane().add(label);
        frame.setVisible(true);
    }
}