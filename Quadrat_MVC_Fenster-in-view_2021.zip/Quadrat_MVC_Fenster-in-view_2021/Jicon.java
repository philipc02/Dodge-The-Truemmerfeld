import javax.swing.*;

public class Jicon extends JFrame
{
    public Jicon(){
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame .setSize(800, 600);
        frame.setLocation(600,300);
        ImageIcon icon = new ImageIcon("H:/Quadrat_MVC_Fenster-in-view_2021/raumschiff.jpg");
        JLabel label = new JLabel(icon,JLabel.CENTER);
        frame.getContentPane().add(label);
        frame.setVisible(true);
    }
    
}