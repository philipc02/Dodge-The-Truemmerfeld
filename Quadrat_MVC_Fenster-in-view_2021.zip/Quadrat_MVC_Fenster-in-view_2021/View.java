import javax.swing.*;
import java.awt.*;

public class View extends javax.swing.JComponent implements ModelBeobachter{
    private Model quadrat;
    private JFrame fenster;

    public View(Model q){
        quadrat = q;
        q.anmelden(this);
        setFocusable(true);
        fenster = new JFrame();
        fenster.add(this);
        fenster.setSize(600, 400);
        fenster.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fenster.setVisible(true);
    }

    public void quadratGeaendert(){
        repaint();
    }

    public void paint(Graphics g){
        g.setColor(Color.BLACK);
        Dimension size = getSize();
        g.fillRect(0, 0, size.width, size.height);
        g.setColor(Color.GREEN);
        g.fillRect(quadrat.getX(), quadrat.getY(), quadrat.getSeitenlaenge(), quadrat.getSeitenlaenge());
    }
    
}