import java.awt.event.*;

public class Controller implements KeyListener{
    private Model quadrat;
    private View viewer;
    
    public Controller(){
        quadrat = new Model();
        viewer = new View(quadrat);
        viewer.addKeyListener(this);
    }
    
    public void keyReleased(KeyEvent e){
        
    }
    
    public void keyPressed(KeyEvent e){
        if(e.getKeyCode() == KeyEvent.VK_D){
            quadrat.nachRechtsBewegen();
        }
        else if(e.getKeyCode() == KeyEvent.VK_A){
            quadrat.nachLinksBewegen();
        }
        else if(e.getKeyCode() == KeyEvent.VK_W){
            quadrat.nachObenBewegen();
        }
        else if(e.getKeyCode() == KeyEvent.VK_S){
            quadrat.nachUntenBewegen();
        }
    }
    
    public void keyTyped(KeyEvent e){
        
    }
}